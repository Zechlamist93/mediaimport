from pathlib import Path
import shutil
import subprocess


# --------------------------------------------------
# MediaImport - Bilder und Videos von CDs/DVDs sammeln
# Linux Mint | Python 3 | keine Zusatzpakete
# --------------------------------------------------

BILD_ENDUNGEN = {
    ".jpg", ".jpeg", ".jpe", ".jfif",
    ".png", ".gif", ".bmp", ".tif", ".tiff",
    ".webp", ".heic", ".heif", ".avif",
    ".raw", ".dng", ".cr2", ".cr3", ".nef", ".nrw",
    ".arw", ".srf", ".sr2", ".orf", ".rw2", ".pef",
    ".raf", ".3fr", ".fff", ".iiq", ".k25", ".kdc",
    ".mos", ".mrw", ".rwl", ".x3f",
    ".psd", ".xcf", ".jp2", ".j2k", ".jpf", ".jpx",
    ".jpm", ".mj2", ".svg",
}

VIDEO_ENDUNGEN = {
    ".mp4", ".m4v", ".mov", ".avi", ".mkv", ".wmv",
    ".mpg", ".mpeg", ".mpe", ".mpv", ".m2v",
    ".3gp", ".3g2", ".mts", ".m2ts", ".ts", ".vob",
    ".ogv", ".ogg", ".webm", ".flv", ".f4v", ".asf",
    ".rm", ".rmvb", ".divx", ".xvid", ".dv", ".mod",
    ".tod", ".mxf", ".mp2", ".m2p", ".qt", ".yuv",
    ".amv", ".nsv", ".roq", ".y4m",
}

MEDIEN_ENDUNGEN = BILD_ENDUNGEN | VIDEO_ENDUNGEN


def desktop_pfad():
    """Ermittelt den Schreibtisch-Ordner."""
    try:
        ergebnis = subprocess.run(
            ["xdg-user-dir", "DESKTOP"],
            capture_output=True,
            text=True,
            check=True,
        )
        pfad = Path(ergebnis.stdout.strip())

        if pfad.is_dir():
            return pfad

    except (FileNotFoundError, subprocess.CalledProcessError):
        pass

    for name in ("Schreibtisch", "Desktop"):
        pfad = Path.home() / name
        if pfad.is_dir():
            return pfad

    raise FileNotFoundError(
        "Schreibtisch nicht gefunden. "
        "Bitte prüfe deine Linux-Mint-Einstellungen."
    )


def zielordner_erstellen():
    """Fragt nach einem Namen und erstellt einen neuen Zielordner."""
    desktop = desktop_pfad()

    while True:
        name = input(
            "\nName des Zielordners auf dem Schreibtisch: "
        ).strip()

        if not name or name in (".", ".."):
            print("Bitte einen gültigen Ordnernamen eingeben.")
            continue

        if "/" in name or "\0" in name:
            print("Bitte keine Schrägstriche im Namen verwenden.")
            continue

        basis = desktop / name
        ziel = basis
        nummer = 2

        # Bereits existierende Ordner niemals verwenden
        while ziel.exists():
            ziel = desktop / f"{name} ({nummer})"
            nummer += 1

        try:
            ziel.mkdir()
            print(f"\nZielordner:\n{ziel}")
            return ziel

        except FileExistsError:
            print("Der Ordnername ist belegt. Bitte erneut versuchen.")


def quelle_abfragen():
    """Fragt nach dem eingehängten CD/DVD-Laufwerk."""
    while True:
        eingabe = input(
            "\nPfad des eingehängten CD/DVD-Laufwerks "
            "(z. B. /media/DEIN_NAME/MEINE_CD): "
        ).strip()

        # Optional um umschließende Anführungszeichen entfernen
        eingabe = eingabe.strip("\"'")

        if not eingabe:
            print("Bitte einen Quellpfad eingeben.")
            continue

        quelle = Path(eingabe).expanduser()

        if not quelle.is_dir():
            print("Dieser Ordner existiert nicht oder ist nicht erreichbar.")
            print("Prüfe, ob die CD/DVD eingelegt und eingehängt ist.")
            continue

        return quelle.resolve()


def medien_suchen(quelle):
    """Sucht rekursiv nach Bild- und Videodateien."""
    gefunden = []
    fehler = 0

    print("\nDurchsuche den Datenträger ...")

    def onerror(error):
        nonlocal fehler
        fehler += 1
        print(f"Lesefehler: {error}")

    # os.walk durchläuft alle Unterordner
    import os

    for ordner, unterordner, dateien in os.walk(
        quelle, onerror=onerror, followlinks=False
    ):
        # Verzeichnisse, die symbolische Links sind, überspringen
        ordnerpfad = Path(ordner)
        unterordner[:] = [
            name for name in unterordner
            if not (ordnerpfad / name).is_symlink()
        ]

        for dateiname in dateien:
            datei = ordnerpfad / dateiname

            try:
                if datei.is_symlink() or not datei.is_file():
                    continue

                if datei.suffix.lower() in MEDIEN_ENDUNGEN:
                    gefunden.append(datei)

            except OSError as error:
                fehler += 1
                print(f"Datei nicht lesbar: {datei} ({error})")

    return gefunden, fehler


def freier_dateipfad(zielordner, dateiname):
    """Ermittelt einen freien Dateinamen ohne Überschreiben."""
    original = Path(dateiname)
    ziel = zielordner / dateiname

    nummer = 2

    while ziel.exists():
        ziel = zielordner / (
            f"{original.stem} ({nummer}){original.suffix}"
        )
        nummer += 1

    return ziel


def medien_kopieren(dateien, zielordner):
    """Kopiert alle gefundenen Medien direkt in den Zielordner."""
    erfolgreich = 0
    fehler = 0
    gesamt_bytes = 0

    for index, quelle in enumerate(dateien, start=1):
        try:
            ziel = freier_dateipfad(zielordner, quelle.name)

            shutil.copy2(quelle, ziel)

            erfolgreich += 1
            gesamt_bytes += ziel.stat().st_size

            print(
                f"[{index}/{len(dateien)}] "
                f"Kopiert: {quelle.name} -> {ziel.name}"
            )

        except (OSError, shutil.Error) as error:
            fehler += 1
            print(f"FEHLER bei {quelle}: {error}")

    return erfolgreich, fehler, gesamt_bytes


def groesse_anzeigen(bytezahl):
    """Gibt Dateigrößen lesbar aus."""
    groesse = float(bytezahl)

    for einheit in ("Byte", "KB", "MB", "GB", "TB"):
        if groesse < 1024 or einheit == "TB":
            return f"{groesse:.2f} {einheit}"
        groesse /= 1024

    return f"{groesse:.2f} TB"


def main():
    print("=" * 52)
    print("             MEDIAIMPORT")
    print("   Bilder und Videos von CD/DVD sammeln")
    print("=" * 52)

    try:
        quelle = quelle_abfragen()
        zielordner = zielordner_erstellen()

        print(f"\nQuelle: {quelle}")
        print(f"Ziel:   {zielordner}")

        dateien, suchfehler = medien_suchen(quelle)

        bilder = sum(
            1 for datei in dateien
            if datei.suffix.lower() in BILD_ENDUNGEN
        )
        videos = len(dateien) - bilder

        print("\nSuchergebnis:")
        print(f"  Bilder: {bilder}")
        print(f"  Videos: {videos}")
        print(f"  Gesamt: {len(dateien)}")

        if suchfehler:
            print(f"  Hinweise auf Lesefehler: {suchfehler}")

        if not dateien:
            print("\nKeine unterstützten Medien gefunden.")
            print("Prüfe den Quellpfad und die Dateiformate.")
            return

        antwort = input(
            "\nSollen diese Dateien jetzt kopiert werden? (j/n): "
        ).strip().lower()

        if antwort not in ("j", "ja"):
            print("Import abgebrochen. Es wurden keine Medien kopiert.")
            return

        print("\nImport läuft ...\n")

        erfolgreich, kopierfehler, gesamt_bytes = medien_kopieren(
            dateien, zielordner
        )

        print("\n" + "=" * 52)
        print("IMPORT ABGESCHLOSSEN")
        print("=" * 52)
        print(f"Erfolgreich kopiert: {erfolgreich}")
        print(f"Kopierfehler:        {kopierfehler}")
        print(f"Übertragene Daten:   {groesse_anzeigen(gesamt_bytes)}")
        print(f"Zielordner:          {zielordner}")

        if suchfehler:
            print(
                "\nAchtung: Bei der Suche gab es Lesefehler. "
                "Möglicherweise wurden nicht alle Dateien gefunden."
            )

        if kopierfehler:
            print(
                "\nAchtung: Einige Dateien konnten nicht kopiert werden."
            )

        print("\nDu kannst den Datenträger jetzt sicher auswerfen.")

    except (FileNotFoundError, PermissionError, OSError) as error:
        print(f"\nAbbruch: {error}")


if __name__ == "__main__":
    main()